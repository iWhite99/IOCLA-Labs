#include <math.h>
#include <stdio.h>

char undefined_function() {
	return 'a';
}
int outsider_var;
